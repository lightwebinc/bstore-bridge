module github.com/lightwebinc/bstore

go 1.27.1

require (
	github.com/bsv-blockchain/go-sdk v1.7.1
	github.com/lightwebinc/bcommon v0.13.0
)

require (
	github.com/mrz1836/go-whatsonchain v1.3.0 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/stretchr/testify v1.12.1 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/crypto v0.57.0 // indirect
	golang.org/x/net v0.59.0 // indirect
)
