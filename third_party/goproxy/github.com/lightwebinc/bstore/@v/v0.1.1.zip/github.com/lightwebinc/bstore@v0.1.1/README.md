# bstore

[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)

Object storage as a market on Bitcoin. A publisher puts an object on the
object plane once; every storage provider subscribed to the bucket receives
the same bytes and competes to hold them. Readers speak S3.

## How it works

- **Publish once, many providers.** An object is a CHIRP (BRC-167) closure
  delivered to every provider on its bucket's blob topic, with a signed
  entry on the bucket's records topic. Providers advertise what they hold
  with ordinary UHRP (BRC-26) advertisements.
- **A bounty races the write.** A publisher may commit a hold bounty that it
  pays, by rank, to the first providers to advertise and pass a challenge,
  with BRC-178's square-root split.
- **Anyone can buy time or proof.** A renewal extends a provider's holding;
  a challenge samples 4 KiB segments chosen from a block hash, the buyer's
  nonce and the provider's key, and proves each into the object's proof
  root, about 5 KB per sample.
- **The bucket proves its own listing.** The owner's chain of mined tokens
  commits to the whole key map, so a reader proves what a key names, that a
  key is absent and that a listing page is complete.
- **Incumbent UHRP hosts join unchanged** through a bridge that speaks
  their HTTP routes.
- **Honest about limits.** Availability is a market outcome, keys are not
  copies, and enforcement is reputation in this version.

## Documentation

| If you want to | Read |
| --- | --- |
| Implement a compatible publisher, provider, host or reader | [docs/spec.md](docs/spec.md) (the specification) |
| Know what cannot change once published | [docs/frozen.md](docs/frozen.md) |
| Use or check the codec and its golden vectors | [docs/codec.md](docs/codec.md) |
| Run an overlay host that carries buckets | [docs/host.md](docs/host.md) |
| Run a storage provider | [docs/provider.md](docs/provider.md) |
| Run the S3 gateway, and what S3 clients can and cannot do through it | [docs/s3.md](docs/s3.md) |
| Own a bucket, put, read, judge a race, settle and challenge from the command line | [docs/usage.md](docs/usage.md) |

## Building

```sh
cd host && npm ci && cd ..
make verify NODE=/path/to/node24
make module NODE=/path/to/node24   # host/bundle/bstore-module.js
go build ./cmd/bstore-provider     # the provider
go build ./cmd/bstore              # the command line, and bstore s3d, the S3 gateway
```

Go 1.27 and Node 24. [docs/codec.md](docs/codec.md) and
[docs/host.md](docs/host.md) say what each target checks.

## Status

Contract signed: every row of [docs/frozen.md](docs/frozen.md) is frozen,
with twenty-four clarifications pending confirmation (section 14). The codec, in
Go and TypeScript, its golden vectors, the overlay host module
(`tm_bstore_`, `tm_bstoreblob_` and `ls_bstore`), the storage provider
(`bstore-provider`), the S3 gateway (`bstore s3d`) and the command line
(`bstore`: the publisher client, which judges the hold race and settles
bounties, and the owner's anchoring tooling) are built; the bridge for
incumbent UHRP hosts comes next.

## License

Apache License 2.0. See [LICENSE](LICENSE).
